<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Default Load Welcome Page
	 */
	public function index(){
		$this->load->view('welcome_message');
	}

	/**
	 * Generate Pdf File from view and Auto Download it.
	 */
	public function generatePdf(){
		$this->load->view('mypdf');
		$html = $this->output->get_output();
		
		$this->load->library('pdf');
		$this->pdf->loadHtml($html);
		$this->pdf->setPaper('A4', 'landscape');
		$this->pdf->render();

		$this->pdf->stream('abc.pdf', array("Attachment"=> 1));	
		file_put_contents($pdfFilePath, $pdf);	
	}


	/**
	 * Generate PDF File and Open It.
	 * User can download or Print Directly from the browser.
	 * File Cannot be Download Automatically.
	 */
	public function previewPdf(){
		$this->load->view('mypdf');
		$html = $this->output->get_output();

		$this->load->library('pdf');
		$this->pdf->loadHtml($html);
		$this->pdf->setPaper('A4', 'landscape');
		$this->pdf->render();

		$this->pdf->stream('abc.pdf', array("Attachment"=> 0));	
		file_put_contents($pdfFilePath, $pdf);	
	}

	/**
	 * Create Dynanic Pdf File, and save it at specific Path.
	 * If that name file already exists than overwrite the pdf file with new one.
	 */
	public function savePdf(){
		$this->load->view('mypdf');
		$html = $this->output->get_output();

		$this->load->library('pdf');
		$this->pdf->loadHtml($html);
		$this->pdf->setPaper('A4', 'landscape');
		$this->pdf->render();

		$pdfFilePath = FCPATH . 'assets/pdf_name.pdf';

		$pdf = $this->pdf->output();
		
		file_put_contents($pdfFilePath, $pdf);	
	}
}
